// ===== CampusCode ReBuild '26 — all page logic (mock data, no backend) =====

// ---------- Mock data ----------
const DEADLINE = new Date("2026-11-06T22:00:00+05:30"); // Round 1 ends 6 Nov, 10 PM IST

const EVENTS = [
  { name: "ReBuild '26", desc: "Recreate the CampusCode flow, then design a brand-new UI.", status: "live", date: "6 Nov", mode: "Individual" },
  { name: "DataSprint", desc: "48-hour analytics challenge on real campus datasets.", status: "sched", date: "21 Nov", mode: "Team of 3" },
  { name: "SupplyHack", desc: "Fix a broken supply chain with code and dashboards.", status: "sched", date: "4 Dec", mode: "Team of 4" },
];

const ROUNDS = [
  {
    num: "01", title: "Round 1 - Recreate", status: "live",
    ends: "Ends 6 Nov, 10:00 PM", deadline: "6 Nov 2026, 10:00 pm", ai: "Not required for this round",
    desc: "Recreate the CampusCode user flow faithfully — Dashboard, Login, Register, and Student dashboard (4 pages). Same layout, same sections, desktop-first. Frontend only, mock data is fine. Submit your dashboard demo (live link + screenshots) any time on Friday, 6 Nov, morning till 10 PM. Individual participation — use your team name for tracking consistently.",
  },
  {
    num: "02", title: "Round 2 - New UI", status: "sched",
    ends: "Opens after Round 1", deadline: "To be announced", ai: "To be announced",
    desc: "Design a brand-new UI for the same flow. Details will be released when the round opens.",
  },
];

const LEADERBOARD = [
  ["Pixel Pushers", "PSG Tech", 92], ["Null Pointers", "SSN", 89],
  ["Vibe Coder", "—", "—"], ["Byte Me", "CIT", 85], ["Stack Overflowers", "Amrita", 81],
];

const ANNOUNCEMENTS = [
  ["6 Nov, 9:00 AM", "Round 1 is live. Submissions close at 10:00 PM tonight."],
  ["5 Nov, 6:30 PM", "Ready-made dashboard templates used as-is will be disqualified."],
];

// ---------- Helpers ----------
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);
const pad = (n) => String(n).padStart(2, "0");

function toast(msg) {
  const t = $("#toast");
  if (!t) return alert(msg);
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2500);
}

// Saved user (localStorage) — wrapped in try/catch in case storage is blocked
function getUser() {
  try { return JSON.parse(localStorage.getItem("cc_user")) || null; } catch { return null; }
}
function setUser(u) {
  try { localStorage.setItem("cc_user", JSON.stringify(u)); } catch {}
}

// Countdown: returns [hours, minutes, seconds] left until DEADLINE
function timeLeft() {
  let diff = Math.max(0, DEADLINE - new Date());
  const h = Math.floor(diff / 3.6e6); diff -= h * 3.6e6;
  const m = Math.floor(diff / 6e4);   diff -= m * 6e4;
  const s = Math.floor(diff / 1000);
  return [h, m, s];
}

// ---------- Landing page ----------
function initLanding() {
  const grid = $("#eventGrid");
  if (!grid) return;
  grid.innerHTML = EVENTS.map((e) => `
    <div class="card event-card">
      <span class="pill ${e.status}">${e.status === "live" ? "Live" : "Scheduled"}</span>
      <h3>${e.name}</h3>
      <p>${e.desc}</p>
      <div class="meta"><span class="label">${e.date}</span><span class="label">${e.mode}</span></div>
    </div>`).join("");

  const inline = $("[data-countdown-inline]");
  const tick = () => { const [h, m, s] = timeLeft(); inline.textContent = `${pad(h)}:${pad(m)}:${pad(s)}`; };
  tick(); setInterval(tick, 1000);
}

// ---------- Login page ----------
function initLogin() {
  const form = $("#loginForm");
  if (!form) return;

  // Student / Organizer toggle
  $$(".tabs-role button").forEach((b) =>
    b.addEventListener("click", () => {
      $$(".tabs-role button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
    })
  );

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = $("#email").value.trim();
    const pass = $("#password").value;
    if (!/^\S+@\S+\.\S+$/.test(email)) return ($("#loginError").textContent = "Enter a valid email.");
    if (pass.length < 6) return ($("#loginError").textContent = "Password must be at least 6 characters.");

    // Mock login: keep a saved name if this email registered before
    const saved = getUser();
    const name = saved && saved.email === email ? saved.name : email.split("@")[0];
    setUser({ name, email });
    window.location.href = "student.html";
  });
}

// ---------- Register page ----------
function initRegister() {
  const form = $("#registerForm");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const err = $("#registerError");
    const f = $("#fname").value.trim(), l = $("#lname").value.trim();
    const email = $("#remail").value.trim();
    const p1 = $("#rpass").value, p2 = $("#rpass2").value;

    if (!f || !l || !$("#college").value.trim() || !$("#year").value) return (err.textContent = "Please fill all required fields.");
    if (!/^\S+@\S+\.\S+$/.test(email)) return (err.textContent = "Enter a valid email.");
    if (p1.length < 6) return (err.textContent = "Password must be at least 6 characters.");
    if (p1 !== p2) return (err.textContent = "Passwords don't match.");
    if (!$("#terms").checked) return (err.textContent = "Please accept the rules.");

    setUser({ name: `${f} ${l}`, email });
    window.location.href = "student.html";
  });
}

// ---------- Student dashboard ----------
let timerId = null;

function renderRound(i) {
  const r = ROUNDS[i];
  $$(".round-tile").forEach((t, idx) => t.classList.toggle("on", idx === i));
  $("#rNum").textContent = i + 1;
  $("#rTitle").textContent = r.title;
  $("#rEnds").textContent = r.ends;
  $("#rDesc").textContent = r.desc;
  $("#rDeadline").textContent = r.deadline;
  $("#rAI").textContent = r.ai;
  const st = $("#rStatus");
  st.className = "pill " + r.status;
  st.textContent = r.status === "live" ? "Live" : "Scheduled";
  $("#timerBox").classList.toggle("hidden", r.status !== "live");
}

function initStudent() {
  if (!$("#roundsList")) return;

  // Show the logged-in user's name (falls back to the default in the HTML)
  const u = getUser();
  if (u) {
    $$("[data-user-name]").forEach((el) => (el.textContent = u.name));
    const initials = u.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
    $$("[data-user-initials]").forEach((el) => (el.textContent = initials));
  }

  // Round tiles
  $("#roundsList").innerHTML = ROUNDS.map((r, i) => `
    <button class="round-tile" data-i="${i}">
      <span class="num">${r.num}</span>
      <span>${r.title.toUpperCase()}</span>
      <span class="pill ${r.status}">${r.status === "live" ? "Live" : "Scheduled"}</span>
    </button>`).join("");
  $$(".round-tile").forEach((b) => b.addEventListener("click", () => renderRound(+b.dataset.i)));
  renderRound(0);

  // Countdown
  const tick = () => {
    const [h, m, s] = timeLeft();
    $("#tH").textContent = pad(h); $("#tM").textContent = pad(m); $("#tS").textContent = pad(s);
  };
  tick(); timerId = setInterval(tick, 1000);

  // Sub-tabs (Overview / Rounds / My Team / ...)
  $$("#subtabs button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#subtabs button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
      $$("[data-panel]").forEach((p) => p.classList.toggle("hidden", p.dataset.panel !== b.dataset.tab));
    })
  );

  // Leaderboard + announcements (mock)
  $("#lbTable").innerHTML += LEADERBOARD.map((r, i) =>
    `<tr class="${r[0] === "Vibe Coder" ? "me" : ""}"><td class="mono">${i + 1}</td><td>${r[0]}</td><td>${r[1]}</td><td class="mono">${r[2]}</td></tr>`
  ).join("");
  $("#annList").innerHTML += ANNOUNCEMENTS.map((a) =>
    `<div style="padding:14px 0;border-bottom:1px dashed var(--line)"><span class="label">${a[0]}</span><p style="margin-top:4px">${a[1]}</p></div>`
  ).join("");

  // Submission form
  $("#submitForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const isUrl = (v) => /^https?:\/\/\S+$/.test(v);
    const gh = $("#gh").value.trim(), demo = $("#demo").value.trim(), note = $("#note").value.trim();
    const err = $("#submitError");
    if (!isUrl(gh) || !gh.includes("github.com")) return (err.textContent = "Enter a valid GitHub link.");
    if (!isUrl(demo)) return (err.textContent = "Enter a valid live demo link.");
    if (!note) return (err.textContent = "Add a note for the organizer.");
    err.textContent = "";
    $("#subStatus").textContent = "Awaiting leader approval";
    toast("Sent to leader for approval ✓");
  });

  $("#refreshBtn").addEventListener("click", () => toast("Up to date"));
  $("#logoutBtn").addEventListener("click", () => { try { localStorage.removeItem("cc_user"); } catch {} });
}

// Run whichever page we're on
initLanding();
initLogin();
initRegister();
initStudent();
