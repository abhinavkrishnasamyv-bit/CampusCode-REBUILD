# CampusCode — ReBuild '26 (Round 1: Recreate)

Frontend recreation of the CampusCode user flow: **Dashboard (landing), Login, Register, Student dashboard**. Plain HTML + CSS + JavaScript, no frameworks, mock data only.

## Pages
| File | Page |
|---|---|
| `index.html` | Public dashboard / landing — live event card with countdown, stats, events, features |
| `login.html` | Login with Student/Organizer toggle and validation |
| `register.html` | Registration form with validation |
| `student.html` | Student Event Hub — sidebar, event tabs, rounds, live countdown, workspace status, submission form |

## How it works
- `css/style.css` — all styling (dark theme, CSS variables at the top).
- `js/app.js` — mock data (events, rounds, leaderboard) at the top, then one `init` function per page. Each function only runs if its page's elements exist.
- Login/Register save the user's name in `localStorage`, so the student dashboard greets them by name.
- The countdown counts down to 6 Nov 2026, 10:00 PM IST.

## Run locally
Just open `index.html` in a browser.
